package application;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import estoqueDeVendas.Estoque;
import estoqueDeVendas.ItemVenda;
import estoqueDeVendas.Produto;
import estoqueDeVendas.Venda;

public class Main {
    public static void main(String[] args) {

        // Criando produtos
        Produto p1 = new Produto("Caneta", 2.50, 40, 30);
        Produto p2 = new Produto("Caderno", 15.00, 50, 20);
        Produto p3 = new Produto("Lápis", 1.00, 200, 50);

        // Criando estoque e adicionando produtos
        Estoque estoque = new Estoque();
        estoque.adicionarProduto(p1);
        estoque.adicionarProduto(p2);
        estoque.adicionarProduto(p3);

        // Lista de vendas
        List<Venda> vendas = new ArrayList<>();

        // Criando vendas
        Venda venda1 = new Venda();
        venda1.adicionarItem(new ItemVenda(p1, 40));
        venda1.adicionarItem(new ItemVenda(p2, 10));
        vendas.add(venda1);

        Venda venda2 = new Venda();
        venda2.adicionarItem(new ItemVenda(p3, 100));
        vendas.add(venda2);

        // Checkout das vendas
        Map<Produto, Double> totalPorProduto = new HashMap<>();
        int contador = 1;

        for (Venda venda : vendas) {
            double total = venda.getTotal();
            System.out.println("Check-out da Venda " + contador + ": R$ " + total);

            for (ItemVenda item : venda.getItens()) {
                Produto produto = item.getProduto();
                int quantidade = item.getQuantidade();
                produto.removerEstoque(quantidade);  // Reduz do estoque

                totalPorProduto.put(produto,
                    totalPorProduto.getOrDefault(produto, 0.0) + item.getSubtotal());
            }

            contador++;
        }

        // Mostrar produtos para reabastecer
        System.out.println("\nProdutos que precisam ser reabastecidos:");
        for (Produto p : estoque.getProdutosParaReabastecer()) {
            System.out.println(p.getNome() + " - Quantidade em estoque: " + p.getQuantidade());
        }

        // Curva ABC
        System.out.println("\nCurva ABC dos produtos vendidos:");
        totalPorProduto.entrySet().stream()
            .sorted(Map.Entry.<Produto, Double>comparingByValue(Comparator.reverseOrder()))
            .forEach(entry -> {
                Produto produto = entry.getKey();
                double total = entry.getValue();
                String categoria;

                if (total >= 100) categoria = "A";
                else if (total >= 50) categoria = "B";
                else categoria = "C";

                System.out.println(produto.getNome() + " - Total vendido: R$ " + total + " - Categoria: " + categoria);
            });
    }

}
