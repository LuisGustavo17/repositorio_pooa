package estoqueDeVendas;

public interface ReabastecimentoStrategy {
    boolean precisaReabastecer(Produto produto);
}
